from flask import(
    Flask,
    request,
    render_template,
    redirect,
    session,
    url_for,
    send_file,
    jsonify,

)
import shutil
import subprocess
import os
import logging
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.urandom(24)


@app.route('/')
def index():
     return render_template('login.html')

def check_password(username,password) -> bool:
    cmd = f"echo '{password}' | su - {username}"
    result = subprocess.run(cmd, shell=True)

    if result.returncode == 0:
        return True
    else:
        return False
@app.route('/login', methods=['POST'])
def login():
        logging.basicConfig(filename='app.log', level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
        username = request.form['username']
        password = request.form['password']
        if check_password(username,password):
            session['username'] = username
            logging.info(f'User {username} logged in')
            response=app.make_response(render_template('home.html'))
            return response
        else:
            return render_template('login.html', error='Invalid username or password')
   
@app.route('/logout')
def logout():
    logging.info(f'User {session["username"]} logged out')
    session.pop('username', None)
    return render_template('login.html')

@app.route('/homedirectory')
def homedirectory():
    home_dir = os.path.expanduser("~")
    items = os.listdir(home_dir)
    table_data = []
    for item in items:
        item_path = os.path.join(home_dir, item)
        if os.path.isdir(item_path):
            size = sum(os.path.getsize(os.path.join(item_path, f)) for f in os.listdir(item_path) if os.path.isfile(os.path.join(item_path, f)))
            mod_time = os.path.getmtime(item_path)
            mod_time_formatted = datetime.fromtimestamp(mod_time).strftime('%Y-%m-%d %H:%M:%S')
            table_data.append({'name': item, 'type': 'directory', 'size':size,'mod_time':mod_time_formatted,'path': item_path})
        elif os.path.isfile(item_path):
            if item.endswith('.txt'):
                size = os.path.getsize(item_path)
                mod_time = os.path.getmtime(item_path)
                mod_time_formatted = datetime.fromtimestamp(mod_time).strftime('%Y-%m-%d %H:%M:%S')
                table_data.append({'name': item, 'type': 'text_file','size':size,'mod_time':mod_time_formatted, 'path': item_path})
            else:
                size = os.path.getsize(item_path)
                mod_time = os.path.getmtime(item_path)
                mod_time_formatted = datetime.fromtimestamp(mod_time).strftime('%Y-%m-%d %H:%M:%S')
                table_data.append({'name': item, 'type': 'file', 'size':size,'mod_time':mod_time_formatted,'path': item_path})
    
    return render_template('home.html', table_data=table_data)

@app.route('/navigate')
def navigate():
    path = request.args.get('path', os.path.expanduser("~"))
    items = os.listdir(path)
    
    
    table_data = []
    for item in items:
        item_path = os.path.join(path, item)
        if os.path.isdir(item_path):
            size = sum(os.path.getsize(os.path.join(item_path, f)) for f in os.listdir(item_path) if os.path.isfile(os.path.join(item_path, f)))
            mod_time = os.path.getmtime(item_path)
            mod_time_formatted = datetime.fromtimestamp(mod_time).strftime('%Y-%m-%d %H:%M:%S')
            table_data.append({'name': item, 'type': 'directory', 'size':size,'mod_time':mod_time_formatted,'path': item_path})
        elif os.path.isfile(item_path):
            if item.endswith('.txt'):
                size = os.path.getsize(item_path)
                mod_time = os.path.getmtime(item_path)
                mod_time_formatted = datetime.fromtimestamp(mod_time).strftime('%Y-%m-%d %H:%M:%S')
                table_data.append({'name': item, 'type': 'text_file','size':size,'mod_time':mod_time_formatted, 'path': item_path})
            else:
                size = os.path.getsize(item_path)
                mod_time = os.path.getmtime(item_path)
                mod_time_formatted = datetime.fromtimestamp(mod_time).strftime('%Y-%m-%d %H:%M:%S')
                table_data.append({'name': item, 'type': 'file','size':size,'mod_time':mod_time_formatted, 'path': item_path})
    
    return render_template('home.html', table_data=table_data)

@app.route('/view_text_file')
def view_text_file():
    path = request.args.get('path')
    if path:
        with open(path, 'r') as f:
            content = f.read()
    else :
            content =''
    
    return render_template('text_file.html', path=path,content=content)



@app.route('/search',methods=['GET', 'POST'])
def find():
    if request.method == 'POST':
        search_term = request.form['query']
        search_results = []
        for root, dirs, files in os.walk(os.path.expanduser("~")):
            for name in files + dirs:
                if search_term in name:
                    path = os.path.join(root, name)
                    stats = os.stat(path)
                    size = stats.st_size
                    date = datetime.fromtimestamp(stats.st_mtime).date()
                    search_results.append({'path':path, 'size':size,'mod_time': date, 'type':'file' if os.path.isfile(path) else 'directory'})
        return render_template('results.html', search_results=search_results)
    else:
        return render_template('home.html')
@app.route('/directories')
def get_directories():
    home_dir = os.path.expanduser("~")
    directories = next(os.walk(home_dir))[1]
    count = len(directories)
    
    return render_template('directories.html', count=count)

@app.route('/num_files')
def num_files():
    file_count = len(os.listdir(os.path.expanduser('~')))
    return render_template('files.html', file_count=file_count)
    
@app.route('/space')
def get_space():
    result = subprocess.run(['df', '-h','.'], capture_output=True, text=True)
    output = result.stdout.strip()

    return render_template('space.html', output=output)

@app.route('/download')
def download():
    logging.info(f'home directory has been downloded')
    home_dir = os.path.expanduser('~') 
    zip_filename = 'home.zip'
    zip_filepath = os.path.join(home_dir, zip_filename)
    os.system(f"zip -r {zip_filepath} {home_dir}")
    return send_file(zip_filepath, as_attachment=True)
@app.errorhandler(Exception)
def error(exception):
    return render_template('error.html',error=
     {
        "ip":request.remote_addr,
        "method":request.method,
        "error" :'sorry im here '
    })
if __name__ == "__main__":
     app.run(port=8080)
